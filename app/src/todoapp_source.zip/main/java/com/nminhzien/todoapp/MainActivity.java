package com.nminhzien.todoapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> TodoList;
    ArrayAdapter<String> aTodoAdapter;
    ListView lvItems;
    EditText etEditText;
    private final int REQUEST_CODE = 01;
    TodoItemDatabase tododb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tododb = new TodoItemDatabase(this);
        TodoList = new ArrayList<String>();
        TodoList = tododb.getAllTasks();

        populateArrayItems();
        lvItems = (ListView) findViewById(R.id.lvItems);
        lvItems.setAdapter(aTodoAdapter);
        etEditText = (EditText) findViewById(R.id.edEditTest);
        //Long Click Listener
        lvItems.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            public boolean onItemLongClick(AdapterView<?> arg0, View v,
                                           int position, long arg3) {
                TodoList.remove(position);
                aTodoAdapter.notifyDataSetChanged();
                tododb.doDeleteaTask(position);
                return true;
            }
        });
        //Click Listener
        lvItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> arg0, View v,
                                       int position, long arg3){
                launchEditItemView(position);
            }
        });
    }

    public void populateArrayItems() {
        aTodoAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, TodoList);
    }

    public void onAddItem(View view) {
        aTodoAdapter.add(etEditText.getText().toString());
        //doInsertRecord(etEditText.getText().toString());
        tododb.addTask(TodoList.size() - 1, etEditText.getText().toString());
        //Log.d("MinhNguyen", " TodoList.size(): "+ Integer.toString(TodoList.size()));
        etEditText.setText("");
    }

    public void launchEditItemView(int pos){
        Intent i =  new Intent(this, EditItemActivity.class);
        i.putExtra("todoItemName", getViewByPosition(pos,lvItems));
        i.putExtra("position", pos);
        startActivityForResult(i, REQUEST_CODE);
    }

    public String getViewByPosition(int pos, ListView listView) {
        final int firstListItemPosition = listView.getFirstVisiblePosition();
        final int lastListItemPosition = firstListItemPosition + listView.getChildCount() - 1;

        if (pos < firstListItemPosition || pos > lastListItemPosition ) {
            return null;
        } else {
            return lvItems.getItemAtPosition(pos).toString();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // REQUEST_CODE is defined above
        if (resultCode == RESULT_OK && requestCode == REQUEST_CODE) {
            String todoItemName = data.getExtras().getString("todoItemName");
            int pos = data.getExtras().getInt("position");
            TodoList.set(pos, todoItemName);
            aTodoAdapter.notifyDataSetChanged();
            // Toast the name to display temporarily on screen
            Toast.makeText(this, "success", Toast.LENGTH_SHORT).show();
            //Save to SQLite Database
            tododb.updateTaskName(pos,todoItemName);
        }
    }

    /*==========SQLite Database=========================*/
//    SQLiteDatabase database=null;
//    public void doCreateDb()
//    {
//        database=openOrCreateDatabase(
//                "todoList.db",
//                MODE_PRIVATE,
//                null);
//    }
//
//    public void doDeleteDb()
//    {
//        String msg="";
//        if(deleteDatabase("qlsinhvien.db")==true)
//        {
//            msg="Delete database [qlsinhvien.db] is successful";
//        }
//        else
//        {
//            msg="Delete database [qlsinhvien.db] is failed";
//        }
//        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
//    }
//
//    public void doCreateTodoTable()
//    {
//        String sql="CREATE TABLE tblTodo (";
//        sql+="id INTEGER primary key,";
//        sql+="name TEXT)";
//        database.execSQL(sql);
//    }
//
//    public void loadallTodo()
//    {
//        doCreateDb();
//        //doCreateTodoTable();
//
//
//        TodoList = new ArrayList<String>();
//        Cursor c=database.query("tblTodo",
//                null, null, null, null, null, null);
//        c.moveToFirst();
//        int i = 0;
//        while(c.isAfterLast()==false)
//        {
//            TodoList.set(i ,c.getString(1));
//            c.moveToNext();
//            i++;
//        }
//        c.close();
//    }
//
//    public void doInsertRecord(String Insert_Item)
//    {
//        ContentValues values=new ContentValues();
//        values.put("id", 00);
//        values.put("name", Insert_Item);
//        String msg="";
//        if(database.insert("tblTodo", null, values)==-1){
//            msg="Failed to insert record";
//        }
//        else{
//            msg="insert record is successful";
//        }
//        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
//    }

}
